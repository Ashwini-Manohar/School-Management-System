<?php
session_start();

$connection = mysqli_connect("localhost","root","","schoolmanagementsystemdb");
if ($connection->connect_error) {
	die("Connection failed: " . $connection->connect_error);
}
else{
	echo "success";
}
/*$sqlFile = 'C:\xampp\htdocs\project\School-Management-System-With-PHP-master\School-Management-System-With-PHP-master\db\schoolmanagementsystemdb.sql';
$sql = file_get_contents($sqlFile);

// Execute SQL queries
if ($connection->multi_query($sql) === TRUE) {
    echo "";
} else {
    echo "Error importing SQL file: " . $connection->error;
}*/

?>
