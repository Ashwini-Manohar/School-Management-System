<?php
session_start();
?>
<?php
include "mysqlcon.php";

$myid = $_POST['myid'];
$mypassword = $_POST['mypassword'];

$query = "SELECT usertype FROM users WHERE userid='$myid' AND password='$mypassword'";
echo usertype;
$result = mysqli_query($connection, $query);

if (mysqli_num_rows($result) == 1) {
    // Fetch the row
    $row = mysqli_fetch_assoc($result);
 
} else {
    echo "User not found or incorrect credentials.";
}
?>

