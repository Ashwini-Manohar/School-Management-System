<?php
include "mysqlcon.php";
$userid = $_POST['myid'];
$password = $_POST['mypassword'];
$query = "SELECT usertype FROM users WHERE userid='$userid' AND password='$password'";
$data = mysqli_query($connection, $query);

if (!$data) {
    // Query failed
    header("Location: ../login.php");
    exit();
}

$result = mysqli_num_rows($data);

if ($result != 1) {
    // No user found with the provided credentials
    header("Location: ../login.php");
    exit();
}

$type = mysqli_fetch_array($data);
$usertype = $type['usertype'];

// Close the previous query result before executing another query
mysqli_free_result($data);

// Redirect based on user type
switch ($usertype) {
    case 'admin':
        header("Location: ../module/admin");
        break;
    case 'teacher':
        header("Location: ../module/teacher");
        break;
    case 'parent':
        header("Location: ../module/parent");
        break;
    case 'student':
        header("Location: ../module/student");
        break;
    case 'staff':
        header("Location: ../module/staff");
        break;
    default:
        header("Location: ../login.php");
        break;
}

// Set session variable
session_start();
$_SESSION['userid'] = $userid;
?>
