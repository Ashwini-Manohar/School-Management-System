<?php
include_once('../../service/mysqlcon.php');
$check=$_SESSION['userid'];
$session=mysqli_query($connection,"SELECT name  FROM admin WHERE id='$check' ");
$row=mysqli_fetch_array($session);
$login_session = $loged_user_name = $row['name'];
if(!isset($login_session)){
    header("Location:../../");
}
?>
