<?php

$connect = mysqli_connect("localhost","root","","schoolmanagementsystemdb");
if($_POST['submit']){
	$id = $_POST['id'];
	$cdate = date("Y-m-d");
	$query = "INSERT INTO attendance VALUES('','$cdate','$id')";
	$result = mysqli_query($connect,$query);
	echo "hi";
}









if($_POST['submit']){
	echo "HI";
    $id = $_POST['id'];
	echo "$id";
    $cdate = date("Y-m-d");
	echo "$cdate";
    $query = "INSERT INTO attendance VALUES('','$cdate','$id')";
	echo "$query";
    $success = mysqli_query($connect,$query);
	echo "$success";
    if(!$success) {
        die('Attendance Error: '.mysqli_error());
    }
    echo "Attendance Complete\n";
    header("Location:../admin/teacherAttendance.php");
}

?>
