<?php
include_once('main.php');
include_once('../../service/mysqlcon.php');
$searchKey = mysqli_real_escape_string($connection, $_GET['key']);

$string = "";
$sql = "SELECT * FROM teachers WHERE id like '$searchKey%' OR name like '$searchKey%';";
$res = mysqli_query($connection,$sql);
while($row = mysqli_fetch_array($res)){
    $string .= '<tr><td>'.$row['id'].'</td><td>'.$row['name'].
    '</td><td>'.$row['phone'].'</td><td>'.$row['email'].
    '</td><td>'.$row['address'].'</td><td>'.$row['sex'].'</td><td>'.$row['dob'].
    '</td><td>'.$row['hiredate'].'</td><td>'.$row['salary'].'</td></tr>';
}
echo $string;
?>
