<?php
include ('../../service/mysqlcon.php');
session_start();
header("Location: ../../login.php");
session_destroy();
?>
