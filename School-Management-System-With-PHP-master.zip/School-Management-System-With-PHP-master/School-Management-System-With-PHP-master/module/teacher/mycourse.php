<?php
include_once('main.php');
$classid = $_REQUEST['classid'];

$check=$_SESSION['userid'];
$courses = "SELECT distinct id , name FROM course WHERE classid='$classid' and teacherid='$check'";
$rescourse = mysqli_query($connection,$courses);

while($r=mysqli_fetch_array($rescourse))
{
 echo '<option value="',$r['id'],'" >',$r['name'],'</option>';

}


?>
