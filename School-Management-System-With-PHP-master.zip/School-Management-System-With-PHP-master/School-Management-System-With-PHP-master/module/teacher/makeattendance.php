<?php
include_once('index.php');

// Assuming 'attendance' is an array in the request
if(isset($_REQUEST['attendance']) && is_array($_REQUEST['attendance'])) {
    $atten = $_REQUEST['attendance'];
    $d = date("Y-m-d");
    
    // Establish database connection
    $conn = mysqli_connect('localhost', 'root', '', 'schoolmanagementsystemdb');
    
    // Check if connection is successful
    if($conn) {
        foreach($atten as $a) {
            $sql = "INSERT INTO attendance (date, attendedid) VALUES ('$d', '$a')";
            mysqli_query($conn, $sql);
        }
        mysqli_close($conn); // Close the database connection
    } else {
        echo "Failed to connect to the database.";
    }
}
?>
<html>
 <center>
 <h4>Attendance Successfully.</h4>
  <p>Go to the home page. Click the Home button.</p>
 </center>
</html>

