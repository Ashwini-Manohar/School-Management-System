<?php
include_once('../../service/mysqlcon.php');
$check=$_SESSION['userid'];
$session=mysqli_query($connection,"SELECT fathername  FROM parents WHERE id='$check' ");
$row=mysqli_fetch_array($session);
$login_session = $loged_user_name = $row['fathername'];
if(!isset($login_session))
{
header("Location:../../mono");
}

?>
